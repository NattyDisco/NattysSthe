// Obsolete. Replaced by components/PWAInstaller.tsx to fix build casing errors.
export {};