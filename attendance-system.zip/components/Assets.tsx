// This component is obsolete. Its functionality has been split into individual asset pages.
import React from 'react';
const Assets: React.FC = () => <div />;
export default Assets;
