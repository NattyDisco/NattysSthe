// This file is obsolete. The operational Staff Registry component is maintained in components/EmployeeList.tsx.
export {};